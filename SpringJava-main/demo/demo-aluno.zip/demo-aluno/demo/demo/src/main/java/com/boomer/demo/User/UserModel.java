package com.boomer.demo.User;

import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity (name = "tb_usuario")
public class UserModel {

    @Id
    @GeneratedValue (generator = "UUID")
    private UUID id;

    private String nome;
    private String username;
    private String senha;
    private String telefone;
    private String email;
}